/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Test;
import java.util.List;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
/**
 *
 * @author Abraham
 */
public class PortalTest {
    
    public static void main(String[] args) {
        //setting driver properties
        System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
        WebDriver WDname = new ChromeDriver();
        //WDname.get("https://google.com.et");
        
        //navigate ur driver to portal.aait.edu.et
        WDname.navigate().to("http://portal.aait.edu.et");
        
        //wait for the element to load
        WDname.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        
        //enter user id
        WDname.findElement(By.id("UserName")).sendKeys("ATR/5539/08");
        
        //enter password
        WDname.findElement(By.id("Password")).sendKeys("14116504");
        
        //click on Log in button
        WDname.findElement(By.cssSelector(".btn-success")).click();
        
        //navigate ur driver to portal.aait.edu.et/Grade/GradeReport
        WDname.navigate().to("http://portal.aait.edu.et/Grade/GradeReport");
        
        WDname.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        
        List<WebElement> x =  WDname.findElements(By.className("yrsm"));
        
        for(WebElement i : x){
            String string=i.findElement(By.tagName("td")).findElement(By.tagName("p")).getText();
            System.out.println(string);
        }
    }
}
